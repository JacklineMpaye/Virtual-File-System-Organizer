import java.util.Map;
import java.util.HashMap;

public class VirtualDirectory 
{
    String name;
    Map<String, VirtualFile> files;
    Map<String, VirtualDirectory> directories;

    // creates a virtual directory

    public VirtualDirectory(String name) 
    {
        this.name = name;
        this.files = new HashMap<>();
        this.directories = new HashMap<>();
    }
}