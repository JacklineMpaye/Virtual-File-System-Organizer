import java.util.Scanner;
import java.util.Stack;

/**
 * Represents a virtual file system with directories and files.
 */
public class VirtualFileSystem {
    private VirtualDirectory root;
    private Stack<VirtualDirectory> currentDirectoryStack;
    private Scanner scanner;

    /**
     * Initializes a new instance of the VirtualFileSystem class.
     */
    public VirtualFileSystem() {
        this.root = new VirtualDirectory("root");
        this.currentDirectoryStack = new Stack<>();
        this.currentDirectoryStack.push(root);
        this.scanner = new Scanner(System.in);
    }

    /**
     * Creates a file in the virtual file system.
     *
     * @param fileName The name of the file to create.
     */
    public void createFile(String fileName) {
        VirtualDirectory currentDirectory = currentDirectoryStack.peek();
        VirtualFile newFile = new VirtualFile(fileName);
        currentDirectory.files.put(fileName, newFile);
        System.out.println("File '" + fileName + "' created in '" + currentDirectory.name + "'.");
    }

    /**
     * Creates a directory in the virtual file system.
     *
     * @param directoryName The name of the directory to create.
     */
    public void createDirectory(String directoryName) {
        VirtualDirectory currentDirectory = currentDirectoryStack.peek();
        VirtualDirectory newDirectory = new VirtualDirectory(directoryName);
        currentDirectory.directories.put(directoryName, newDirectory);
        System.out.println("Directory '" + directoryName + "' created in '" + currentDirectory.name + "'.");
    }

    /**
     * Deletes a file from the virtual file system.
     *
     * @param fileName The name of the file to delete.
     */
    public void deleteFile(String fileName) {
        VirtualDirectory currentDirectory = currentDirectoryStack.peek();
        String normalizedFileName = fileName.toLowerCase(); // Convert to lowercase for case-insensitive comparison

        if (currentDirectory.files.containsKey(normalizedFileName)) {
            currentDirectory.files.remove(normalizedFileName);
            System.out.println("File '" + fileName + "' deleted from '" + currentDirectory.name + "'.");
        } else {
            System.out.println("File '" + fileName + "' not found in '" + currentDirectory.name + "'.");
        }
    }

    /**
     * Deletes a directory from the virtual file system.
     *
     * @param directoryName The name of the directory to delete.
     */
    public void deleteDirectory(String directoryName) {
        VirtualDirectory currentDirectory = currentDirectoryStack.peek();
        String normalizedDirectoryName = directoryName.toLowerCase(); // Convert to lowercase for case-insensitive comparison

        if (currentDirectory.directories.containsKey(normalizedDirectoryName)) {
            currentDirectory.directories.remove(normalizedDirectoryName);
            System.out.println("Directory '" + directoryName + "' deleted from '" + currentDirectory.name + "'.");
        } else {
            System.out.println("Directory '" + directoryName + "' not found in '" + currentDirectory.name + "'.");
        }
    }

    /**
     * Moves to a directory in the virtual file system.
     *
     * @param directoryName The name of the directory to move to.
     */
    public void move(String directoryName) {
        VirtualDirectory currentDirectory = currentDirectoryStack.peek();
        if (currentDirectory.directories.containsKey(directoryName)) {
            VirtualDirectory newCurrentDirectory = currentDirectory.directories.get(directoryName);
            currentDirectoryStack.push(newCurrentDirectory);
            System.out.println("Moved to directory '" + directoryName + "'.");
        } else {
            System.out.println("Directory '" + directoryName + "' not found in '" + currentDirectory.name + "'.");
        }
    }

    /**
     * Moves back to the parent directory.
     */
    public void moveBack() {
        if (currentDirectoryStack.size() > 1) {
            currentDirectoryStack.pop();
            System.out.println("Moved back to parent directory.");
        } else {
            System.out.println("Already at the root directory.");
        }
    }

    /**
     * Searches for a file by name using hashing.
     *
     * @param fileName The name of the file to search for.
     * @return The found file or null if not found.
     */
    public VirtualFile searchFile(String fileName) {
        VirtualDirectory currentDirectory = currentDirectoryStack.peek();
        String normalizedFileName = fileName.toLowerCase(); // Convert to lowercase for case-insensitive comparison

        if (currentDirectory.files.containsKey(normalizedFileName)) {
            return currentDirectory.files.get(normalizedFileName);
        } else {
            System.out.println("File '" + fileName + "' not found in '" + currentDirectory.name + "'.");
            return null;
        }
    }

    /**
     * Displays the file system tree.
     */
    public void displayFileSystem() {
        displayFileSystemHelper(root, 0);
    }

    /**
     * Helper method to display the file system tree.
     *
     * @param directory The current directory to display.
     * @param depth     The depth of the directory in the file system tree.
     */
    private void displayFileSystemHelper(VirtualDirectory directory, int depth) {
        // Implement the logic to display the file system tree using depth-first traversal
        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            indent.append("  ");
        }
        System.out.println(indent.toString() + directory.name + "/");
        for (VirtualFile file : directory.files.values()) {
            System.out.println(indent.toString() + "  - " + file.name);
        }
        for (VirtualDirectory subDirectory : directory.directories.values()) {
            displayFileSystemHelper(subDirectory, depth + 1);
        }
    }

    /**
     * Resolves file paths and navigates through the directory tree.
     *
     * @param path The path to navigate.
     */
    public void navigate(String path) {
        // Use stacks or queues to resolve file paths and navigate through the directory tree
        Stack<String> pathStack = new Stack<>();
        String[] pathSegments = path.split("/");
        for (String segment : pathSegments) {
            if (!segment.isEmpty()) {
                pathStack.push(segment);
            }
        }

        while (!pathStack.isEmpty()) {
            String segment = pathStack.pop();
            if (segment.equals("..")) {
                moveBack();
            } else {
                move(segment);
            }
        }
    }

    /**
     * Moves a file to a directory in the virtual file system.
     *
     * @param fileName           The name of the file to move.
     * @param targetDirectoryName The name of the target directory.
     */
    public void moveFileToDirectory(String fileName, String targetDirectoryName) {
        VirtualDirectory currentDirectory = currentDirectoryStack.peek();
        String normalizedFileName = fileName.toLowerCase(); // Convert to lowercase for case-insensitive comparison

        if (currentDirectory.files.containsKey(normalizedFileName)) {
            VirtualFile fileToMove = currentDirectory.files.get(normalizedFileName);

            // Get the target directory
            VirtualDirectory targetDirectory = currentDirectory.directories.get(targetDirectoryName.toLowerCase());
            if (targetDirectory != null) {
                targetDirectory.files.put(normalizedFileName, fileToMove);
                currentDirectory.files.remove(normalizedFileName);
                System.out.println("File '" + fileName + "' moved to directory '" + targetDirectoryName + "'.");
            } else {
                System.out.println("Target directory '" + targetDirectoryName + "' not found.");
            }
        } else {
            System.out.println("File '" + fileName + "' not found in '" + currentDirectory.name + "'.");
        }
    }

    /**
     * Moves a directory to another directory in the virtual file system.
     *
     * @param sourceDirectoryName The name of the source directory.
     * @param targetDirectoryName The name of the target directory.
     */
    public void moveDirectoryToDirectory(String sourceDirectoryName, String targetDirectoryName) {
        VirtualDirectory currentDirectory = currentDirectoryStack.peek();
        String normalizedSourceDirectoryName = sourceDirectoryName.toLowerCase();
        // Convert to lowercase for case-insensitive comparison

        if (currentDirectory.directories.containsKey(normalizedSourceDirectoryName)) {
            VirtualDirectory sourceDirectory = currentDirectory.directories.get(normalizedSourceDirectoryName);

            // Get the target directory
            VirtualDirectory targetDirectory = currentDirectory.directories.get(targetDirectoryName.toLowerCase());
            if (targetDirectory != null) {
                targetDirectory.directories.put(normalizedSourceDirectoryName, sourceDirectory);
                currentDirectory.directories.remove(normalizedSourceDirectoryName);
                System.out.println("Directory '" + sourceDirectoryName + "' moved to directory '" + targetDirectoryName + "'.");
            } else {
                System.out.println("Target directory '" + targetDirectoryName + "' not found.");
            }
        } else {
            System.out.println("Directory '" + sourceDirectoryName + "' not found in '" + currentDirectory.name + "'.");
        }
    }

    /**
     * Executes the virtual file system by providing a menu-driven interface.
     */
    public void run() {
        boolean exit = false;

        while (!exit) {
            System.out.println("\nOptions:");
            System.out.println("1. Create File");
            System.out.println("2. Create Directory");
            System.out.println("3. Move File to Directory");
            System.out.println("4. Move Directory to Directory");
            System.out.println("5. Delete File");
            System.out.println("6. Delete Directory");
            System.out.println("7. Move Back");
            System.out.println("8. Search for File");
            System.out.println("9. Display File System");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter the file name: ");
                    String fileName = scanner.nextLine();
                    createFile(fileName);
                    break;
                case 2:
                    System.out.print("Enter the directory name: ");
                    String dirName = scanner.nextLine();
                    createDirectory(dirName);
                    break;
                case 3:
                    System.out.print("Enter the file name to move: ");
                    String moveFileName = scanner.nextLine();

                    System.out.print("Enter the target directory name: ");
                    String targetDirectoryName = scanner.nextLine();

                    moveFileToDirectory(moveFileName, targetDirectoryName);
                    break;
                case 4:
                    System.out.print("Enter the source directory name: ");
                    String sourceDirName = scanner.nextLine();

                    System.out.print("Enter the target directory name: ");
                    String targetDirName = scanner.nextLine();

                    moveDirectoryToDirectory(sourceDirName, targetDirName);
                    break;
                case 5:
                    System.out.print("Enter the file name to delete: ");
                    String deleteFileName = scanner.nextLine();
                    deleteFile(deleteFileName);
                    break;
                case 6:
                    System.out.print("Enter the directory name to delete: ");
                    String deleteDirName = scanner.nextLine();
                    deleteDirectory(deleteDirName);
                    break;
                case 7:
                    moveBack();
                    break;
                case 8:
                    System.out.print("Enter the file name to search: ");
                    String searchFileName = scanner.nextLine();
                    VirtualFile foundFile = searchFile(searchFileName);

                    if (foundFile != null) {
                        System.out.println("File '" + foundFile.name + "' found in '" + currentDirectoryStack.peek().name + "'.");
                    }
                    break;
                case 9:
                    displayFileSystem();
                    break;
                case 10:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
