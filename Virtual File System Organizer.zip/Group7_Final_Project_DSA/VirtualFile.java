public class VirtualFile 
{
    String name;

    // creates a VirtualFile given a name
    
    public VirtualFile(String name) {
        this.name = name;
    }
}