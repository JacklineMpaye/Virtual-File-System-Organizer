public class Main 
{
    public static void main(String[] args)
    {
        VirtualFileSystem vfs = new VirtualFileSystem();
        vfs.run();
    }
}
